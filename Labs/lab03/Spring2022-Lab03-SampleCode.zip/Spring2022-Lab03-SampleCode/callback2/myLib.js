module.exports = {
  dirSorted : function (dir, callback) {
  }
 };
