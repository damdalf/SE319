  let person = require('./myLib.js');
  console.log(person.name)
