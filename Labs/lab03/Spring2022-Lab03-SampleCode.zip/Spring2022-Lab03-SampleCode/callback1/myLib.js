module.exports = {'name': "Tom", 'age':20 };
