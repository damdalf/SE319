// @ts-check
function showDate(){
    var myDate = Date();
    document.getElementById('demo').innerHTML = myDate
    console.log(myDate)
}

